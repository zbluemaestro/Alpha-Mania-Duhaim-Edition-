import React, { useState } from 'react';
import { Header } from './components/Header';
import { Home } from './components/Home';
import { Hero } from './components/Hero';
import { CategoryView } from './components/CategoryView';
import { Pricing } from './components/Pricing';
import { Community } from './components/Community';
import { Footer } from './components/Footer';
import { Category, ViewMode } from './types';

export default function App() {
  const [activeCategory, setActiveCategory] = useState<Category>('Styles');
  const [currentView, setCurrentView] = useState<ViewMode>('Home');

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-50 font-sans selection:bg-emerald-500/30 flex flex-col">
      <Header 
        activeCategory={activeCategory} 
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          setCurrentView('Library');
        }} 
        currentView={currentView}
        onSelectView={setCurrentView}
      />
      
      <main className="flex-1">
        {currentView === 'Home' && <Home onExplore={() => setCurrentView('Library')} />}
        {currentView === 'Library' && (
          <>
            <Hero />
            <CategoryView category={activeCategory} />
          </>
        )}
        {currentView === 'Pricing' && <Pricing />}
        {currentView === 'Community' && <Community />}
      </main>

      <Footer />
    </div>
  );
}
