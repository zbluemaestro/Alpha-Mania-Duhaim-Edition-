export type Category = 'Styles' | 'Directors' | 'Storyboards' | 'Video' | 'Music' | 'Posters' | 'Characters' | 'Freebies';
export type ViewMode = 'Home' | 'Library' | 'Pricing' | 'Community';

export interface PromptItem {
  id: string;
  title: string;
  description: string;
  promptText: string;
  category: Category;
  genre: string;
  imageUrl: string;
  isPremium?: boolean;
}

