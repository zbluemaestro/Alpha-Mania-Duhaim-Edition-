import { PromptItem, Category } from '../types';

export const GENRES = [
  'Historical', 'War', 'Sci-Fi', 'Psychological Horror', 'Fantasy',
  'Action', 'Thriller', 'Drama', 'Mystery', 'Cyberpunk',
  'Post-Apocalyptic', 'Romance', 'Crime'
];

export const DIRECTORS = [
  { name: 'Zack Snyder', style: 'High contrast, muted colors, slow-motion feel, gritty, dark, epic scale, dramatic lighting.' },
  { name: 'Christopher Nolan', style: 'Cold color palette, IMAX format, practical effects feel, urban landscapes, sharp focus.' },
  { name: 'Quentin Tarantino', style: 'Retro 70s film stock, vibrant colors, low angle shots, dynamic composition, high contrast.' },
  { name: 'Wes Anderson', style: 'Perfect symmetry, pastel color palette, flat composition, quirky props, vintage aesthetic.' },
  { name: 'Denis Villeneuve', style: 'Brutalist architecture, atmospheric haze, monochromatic color schemes, immense sense of scale.' },
  { name: 'Martin Scorsese', style: 'Gritty urban realism, dynamic camera movement feel, neon reflections, high energy.' }
];

export const STYLES = [
  'Pixar', 'Anime', 'Marvel Comics', 'Cartoon Network', 'Spider-Verse', 'Classic Comic', 'Cyberpunk',
  'Steampunk', 'Watercolor', 'Oil Painting', 'Synthwave', 'Studio Ghibli', 'Film Noir', 'Low Poly',
  'Origami', 'Claymation', 'Voxel'
];

const VIDEO_ACTIONS = ['Epic battle', 'High-speed chase', 'Emotional dialogue', 'Slow-motion walk', 'Explosive action', 'Stealth infiltration', 'Magical transformation', 'Space dogfight', 'Hand-to-hand combat', 'Dramatic reveal'];
const VIDEO_TYPES = ['Animate existing frame', 'Generate new sequence'];

const MUSIC_MOODS = ['Calm', 'War', 'Conflict', 'Tense', 'Epic', 'Melancholy', 'Joyful', 'Mysterious', 'Ethereal', 'Aggressive'];
const MUSIC_INSTRUMENTS = ['Orchestral strings', 'Heavy synths', 'Tribal drums', 'Acoustic piano', 'Electric guitar', 'Choir', 'Ambient pads', 'Brass section'];

const POSTER_BASES = [
  'The Godfather', 'Interstellar', 'Spider-Man 3', 'Man of Steel', 'The Dark Knight Rises', 'Up', 'John Wick', 'The Shawshank Redemption', 'The Avengers', 'Guardians of the Galaxy',
  'Inception', 'The Matrix', 'Jurassic Park', 'Star Wars', 'Blade Runner', 'Mad Max: Fury Road', 'Gladiator', 'Alien', 'Terminator 2', 'Back to the Future'
];

const CHARACTERS = [
  'Thomas Shelby', 'John Wick', 'James Bond', 'Neo', 'Trinity', 'Morpheus',
  'Walter White', 'Jesse Pinkman', 'Saul Goodman', 'Tony Soprano',
  'Jon Snow', 'Daenerys Targaryen', 'Tyrion Lannister', 'Arya Stark',
  'Aragorn', 'Legolas', 'Gandalf', 'Frodo Baggins', 'Gollum',
  'Harry Potter', 'Hermione Granger', 'Severus Snape', 'Sirius Black',
  'Bruce Wayne', 'Clark Kent', 'Diana Prince', 'Arthur Curry', 'Barry Allen',
  'Tony Stark', 'Steve Rogers', 'Natasha Romanoff', 'Thor Odinson', 'Bruce Banner',
  'Peter Parker', 'Stephen Strange', 'Wanda Maximoff', 'Bucky Barnes',
  'Sam Wilson', 'T\'Challa', 'Carol Danvers', 'Scott Lang', 'Hope van Dyne',
  'Peter Quill', 'Gamora', 'Drax', 'Nick Fury', 'Loki',
  'Wolverine', 'Charles Xavier', 'Magneto', 'Jean Grey',
  'Deadpool', 'Cable', 'Domino',
  'Indiana Jones', 'Han Solo', 'Luke Skywalker', 'Princess Leia', 'Darth Vader',
  'Obi-Wan Kenobi', 'Anakin Skywalker', 'Padme Amidala', 'Mace Windu', 'Kylo Ren',
  'Rey', 'Finn', 'Poe Dameron', 'The Mandalorian', 'Greef Karga',
  'Ellen Ripley', 'Sarah Connor', 'Terminator', 'John Connor',
  'Max Rockatansky', 'Furiosa', 'Rick Deckard', 'Roy Batty', 'K (Blade Runner)',
  'Paul Atreides', 'Chani', 'Duke Leto', 'Baron Harkonnen', 'Duncan Idaho',
  'Katniss Everdeen', 'Peeta Mellark', 'Gale Hawthorne', 'Haymitch Abernathy',
  'Bella Swan', 'Edward Cullen', 'Jacob Black',
  'Jack Sparrow', 'Will Turner', 'Elizabeth Swann', 'Hector Barbossa',
  'Ethan Hunt', 'Jason Bourne', 'Bryan Mills', 'Robert McCall',
  'Rocky Balboa', 'Adonis Creed', 'Ivan Drago',
  'Michael Corleone', 'Vito Corleone', 'Tommy DeVito', 'Henry Hill',
  'Travis Bickle', 'Patrick Bateman', 'Tyler Durden', 'The Narrator',
  'Joker', 'Bane', 'Scarecrow', 'Ra\'s al Ghul', 'Harvey Dent', 'Catwoman',
  'Geralt of Rivia', 'Yennefer', 'Ciri',
  'Joel Miller', 'Ellie Williams', 'Nathan Drake', 'Lara Croft',
  'Arthur Morgan', 'John Marston',
  'Sherlock Holmes', 'John Watson', 'Hercule Poirot',
  'Hannibal Lecter', 'Clarice Starling', 'Norman Bates',
  'Dexter Morgan', 'Rust Cohle', 'Martin Hart',
  'Rick Grimes', 'Daryl Dixon', 'Michonne', 'Negan',
  'Homelander', 'Billy Butcher', 'Hughie Campbell', 'Starlight', 'Soldier Boy',
  'Peacemaker', 'Bloodsport', 'Rick Flag',
  'Immortan Joe', 'Agent Smith', 'Oracle', 'Niobe',
  'John McClane', 'Hans Gruber', 'Martin Riggs', 'Roger Murtaugh',
  'Axel Foley', 'RoboCop', 'Judge Dredd',
  'William Wallace', 'Maximus', 'Leonidas', 'Achilles',
  'Robin Hood', 'King Arthur', 'Lancelot',
  'Dracula', 'Frankenstein', 'The Mummy', 'Wolfman',
  'Pennywise', 'Michael Myers', 'Jason Voorhees', 'Freddy Krueger',
  'Ghostface', 'Leatherface', 'Pinhead', 'Chucky',
  'Ash Williams', 'Shaun', 'Nicholas Angel',
  'Eggsy Unwin', 'Harry Hart', 'Richmond Valentine',
  'Dominic Toretto', 'Brian O\'Conner', 'Luke Hobbs', 'Deckard Shaw',
  'Frank Martin', 'Chev Chelios',
  'Danny Ocean', 'Rusty Ryan', 'Linus Caldwell',
  'Jordan Belfort', 'Gordon Gekko', 'Don Draper',
  'Arthur Shelby', 'Polly Gray', 'Alfie Solomons',
  'Uhtred', 'Ragnar Lothbrok', 'Bjorn Ironside', 'Ivar the Boneless',
  'John Rambo', 'Dutch', 'John Matrix'
].sort(() => 0.5 - Math.random());

let idCounter = 1;
const generateId = () => `p_${idCounter++}`;

const LONG_DESCRIPTIVE_SUFFIX = "The composition is meticulously crafted, focusing on the interplay of light and shadow to create depth and volume. The textures are incredibly lifelike, capturing every micro-detail of the surface, from the roughness of the environment to the subtle imperfections. The atmosphere is thick with emotion, drawing the viewer into the scene and establishing a strong narrative context. The lighting setup utilizes a complex array of practical and motivated sources, casting dynamic highlights and deep, rich shadows that enhance the three-dimensionality. The camera lens choice emphasizes the depth of field, isolating the subject while maintaining a beautifully blurred, bokeh-rich background. The color grading is carefully tuned to evoke a specific mood, with subtle shifts in hue and saturation that enhance the overall cinematic feel. Every element within the frame is intentionally placed, contributing to a sense of scale, grandeur, and visual balance. The image is rendered in stunning 8k resolution, ensuring that even the smallest details are preserved with absolute clarity. The overall aesthetic is a perfect blend of technical mastery and artistic vision, resulting in a truly breathtaking visual experience that resonates on a profound level.";

export const prompts: PromptItem[] = [];

// 1. Generate Directors
DIRECTORS.forEach(director => {
  GENRES.forEach(genre => {
    prompts.push({
      id: generateId(),
      title: director.name,
      description: `Cinematic shot directed by ${director.name}.`,
      promptText: `A cinematic wide shot, directed by ${director.name}. ${director.style} ${LONG_DESCRIPTIVE_SUFFIX}`,
      category: 'Directors',
      genre: genre,
      imageUrl: `https://picsum.photos/seed/dir_${director.name.replace(/\s/g, '')}_${genre}/800/600`,
      isPremium: false
    });
  });
});

// 2. Generate Styles
STYLES.forEach(style => {
  GENRES.forEach(genre => {
    prompts.push({
      id: generateId(),
      title: style,
      description: `Image generation prompt in the exact visual style of ${style}.`,
      promptText: `A visually stunning scene rendered in the exact visual style of ${style}. High quality, detailed, characteristic colors and shading of ${style}. ${LONG_DESCRIPTIVE_SUFFIX}`,
      category: 'Styles',
      genre: genre,
      imageUrl: `https://picsum.photos/seed/style_${style.replace(/\s/g, '')}_${genre}/800/600`,
      isPremium: false
    });
  });
});

// 3. Generate Video Prompts
VIDEO_ACTIONS.forEach((action, i) => {
  const type = VIDEO_TYPES[i % VIDEO_TYPES.length];
  GENRES.forEach(genre => {
    prompts.push({
      id: generateId(),
      title: `${action} (${type})`,
      description: `Video generation prompt for ${action.toLowerCase()}.`,
      promptText: `${type === 'Animate existing frame' ? 'Animate this image: ' : 'Generate a video sequence: '} A scene featuring a ${action.toLowerCase()}. Smooth motion, cinematic camera panning, 60fps, high quality. The motion should be fluid and realistic, capturing the weight and momentum of the subjects. The lighting should dynamically shift as the camera moves, revealing new details and enhancing the dramatic tension. The depth of field should adjust smoothly, keeping the main action in sharp focus while the background elements blur naturally. Every frame should look like a carefully composed photograph, maintaining consistent color grading and atmospheric effects throughout the sequence.`,
      category: 'Video',
      genre: genre,
      imageUrl: `https://picsum.photos/seed/vid_${action.replace(/\s/g, '')}_${genre}/800/600`,
      isPremium: false
    });
  });
});

// 4. Generate Music Prompts
MUSIC_MOODS.forEach((mood, i) => {
  const instrument = MUSIC_INSTRUMENTS[i % MUSIC_INSTRUMENTS.length];
  GENRES.forEach(genre => {
    prompts.push({
      id: generateId(),
      title: `${mood} Theme`,
      description: `Music generation prompt featuring ${instrument.toLowerCase()}.`,
      promptText: `Create a ${mood.toLowerCase()} soundtrack. The main instrumentation should feature ${instrument.toLowerCase()}. High quality audio, cinematic mixing, emotional depth. The composition should start with a subtle, atmospheric intro that gradually builds in intensity and complexity. The melody should be memorable and evocative. The arrangement should include dynamic shifts in tempo and volume, creating a sense of narrative progression. The final mix should be wide and immersive, with clear separation between the different instruments and a rich, resonant low end. The overall feel should be professional, polished, and ready to be used in a high-end production.`,
      category: 'Music',
      genre: genre,
      imageUrl: `https://picsum.photos/seed/mus_${mood}_${genre}/800/600`,
      isPremium: false
    });
  });
});

// 5. Generate Poster Prompts
POSTER_BASES.forEach(base => {
  GENRES.forEach(genre => {
    prompts.push({
      id: generateId(),
      title: base,
      description: `Movie poster prompt adapting the layout of ${base}.`,
      promptText: `A movie poster. The visual composition, typography placement, and color grading should be heavily inspired by the official poster for "${base}", but featuring entirely new characters and setting. Masterpiece, trending on ArtStation. ${LONG_DESCRIPTIVE_SUFFIX.replace('The image is rendered', 'The poster is rendered')}`,
      category: 'Posters',
      genre: genre,
      imageUrl: `https://picsum.photos/seed/pos_${base.replace(/\s/g, '')}_${genre}/800/600`,
      isPremium: false
    });
  });
});

// 6. Generate Character Prompts
CHARACTERS.forEach((character, index) => {
  const genre = GENRES[index % GENRES.length];
  prompts.push({
    id: generateId(),
    title: character,
    description: `Character replacement prompt featuring ${character}.`,
    promptText: `A highly detailed, photorealistic close-up portrait of ${character}. The composition is tightly framed on the face, making it perfect for face-swapping and user face replacement. The facial features must perfectly match the iconic look of ${character}, while the clothing, lighting, and background should seamlessly integrate them into the environment. ${LONG_DESCRIPTIVE_SUFFIX}`,
    category: 'Characters',
    genre: genre,
    imageUrl: `https://picsum.photos/seed/char_${character.replace(/[^a-zA-Z0-9]/g, '')}/800/600`,
    isPremium: false
  });
});

const STORYBOARD_SCENES = ['Opening Scene', 'Chase Sequence', 'Final Confrontation', 'Emotional Climax', 'Establishing Shot', 'Montage Sequence'];

// 7. Generate Storyboards
STORYBOARD_SCENES.forEach(scene => {
  GENRES.forEach(genre => {
    prompts.push({
      id: generateId(),
      title: scene,
      description: `Storyboard sequence prompt for a ${scene.toLowerCase()}.`,
      promptText: `A detailed storyboard sequence consisting of 6 panels. The sequence depicts a ${scene.toLowerCase()}. Panel 1: Wide establishing shot. Panel 2: Medium shot introducing the subject. Panel 3: Close-up on a crucial detail. Panel 4: Over-the-shoulder shot showing perspective. Panel 5: Dynamic action or reaction shot. Panel 6: Wide pull-out shot concluding the sequence. Each panel should be sketched in a professional cinematic storyboard style with clear directional arrows for camera movement and character action. High contrast black and white with subtle shading.`,
      category: 'Storyboards',
      genre: genre,
      imageUrl: `https://picsum.photos/seed/story_${scene.replace(/\s/g, '')}_${genre}/800/600`,
      isPremium: false
    });
  });
});

// 8. Generate Freebies
const FREEBIE_EVENTS = [
  { title: 'World War II Soldier', prompt: 'A highly detailed, photorealistic close-up portrait of a World War II soldier in the trenches. The composition is tightly framed on the face, perfect for face-swapping. Deep realistic style, gritty textures, dramatic lighting.', category: 'Characters' },
  { title: 'Conquest of Constantinople', prompt: 'A highly detailed, photorealistic close-up portrait of an Ottoman warrior during the Conquest of Constantinople. The composition is tightly framed on the face, perfect for face-swapping. Deep realistic style, cinematic lighting, historical accuracy.', category: 'Characters' },
  { title: 'Moon Landing Astronaut', prompt: 'A highly detailed, photorealistic close-up portrait of an astronaut during the 1969 moon landing, visor reflecting the lunar surface. Tightly framed on the face, perfect for face-swapping. Deep realistic style, high contrast.', category: 'Characters' },
  { title: 'Cyberpunk Hacker', prompt: 'A highly detailed, photorealistic close-up portrait of a cyberpunk hacker illuminated by neon screens. Tightly framed on the face, perfect for face-swapping. Deep realistic style, vibrant colors.', category: 'Characters' },
  
  // New Freebies for other categories
  { title: 'Epic Fantasy Battle', prompt: 'A cinematic wide shot of an epic fantasy battle between knights and dragons. High contrast, dramatic lighting, immense scale.', category: 'Directors' },
  { title: 'Neon Cityscape', prompt: 'A visually stunning scene of a futuristic neon cityscape in the rain. High quality, detailed, characteristic colors and shading.', category: 'Styles' },
  { title: 'Slow-motion explosion', prompt: 'Generate a video sequence: A scene featuring a slow-motion explosion in an abandoned warehouse. Smooth motion, cinematic camera panning, 60fps, high quality.', category: 'Video' },
  { title: 'Epic Orchestral Theme', prompt: 'Create an epic soundtrack. The main instrumentation should feature orchestral strings and heavy brass. High quality audio, cinematic mixing, emotional depth.', category: 'Music' },
  { title: 'Sci-Fi Movie Poster', prompt: 'A movie poster. The visual composition, typography placement, and color grading should be heavily inspired by classic 80s sci-fi posters. Masterpiece, trending on ArtStation.', category: 'Posters' },
  { title: 'Chase Sequence Storyboard', prompt: 'A detailed storyboard sequence consisting of 6 panels. The sequence depicts a high-speed car chase. Panel 1: Wide establishing shot. Panel 2: Medium shot introducing the subject. Panel 3: Close-up on a crucial detail. Panel 4: Over-the-shoulder shot showing perspective. Panel 5: Dynamic action or reaction shot. Panel 6: Wide pull-out shot concluding the sequence.', category: 'Storyboards' }
];

FREEBIE_EVENTS.forEach((event, i) => {
  prompts.push({
    id: generateId(),
    title: event.title,
    description: `Premium quality ${event.category.toLowerCase()} prompt, available for free.`,
    promptText: `${event.prompt} ${LONG_DESCRIPTIVE_SUFFIX}`,
    category: 'Freebies',
    genre: 'General',
    imageUrl: `https://picsum.photos/seed/free_event_${i}/800/600`,
    isPremium: false
  });
});

for (let i = 1; i <= 4; i++) {
  prompts.push({
    id: generateId(),
    title: `Freebie Masterpiece ${i}`,
    description: `A premium quality prompt, available for free.`,
    promptText: `A breathtaking, award-winning masterpiece. The lighting is dramatic and cinematic, casting long shadows and highlighting the intricate details of the subject. The composition follows the rule of thirds, drawing the viewer's eye through the frame. Rendered in stunning 8k resolution with hyper-realistic textures and a perfect balance of color and contrast. This image should evoke a strong emotional response and tell a compelling story without words.`,
    category: 'Freebies',
    genre: 'General',
    imageUrl: `https://picsum.photos/seed/free_${i}/800/600`,
    isPremium: false
  });
}

