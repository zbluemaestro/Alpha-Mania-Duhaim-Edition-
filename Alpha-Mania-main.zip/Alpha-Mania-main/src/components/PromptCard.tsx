import React, { useState } from 'react';
import { PromptItem } from '../types';
import { Copy, Check, Lock, ChevronDown } from 'lucide-react';
import { DIRECTORS, STYLES } from '../data/database';

interface PromptCardProps {
  prompt: PromptItem;
  showGenreInTitle?: boolean;
}

export function PromptCard({ prompt, showGenreInTitle }: PromptCardProps) {
  const [copied, setCopied] = useState(false);
  const [selectedDirector, setSelectedDirector] = useState<string>('');
  const [selectedStyle, setSelectedStyle] = useState<string>('');

  const handleCopy = () => {
    if (prompt.isPremium) return;
    
    let finalPrompt = prompt.promptText;
    if (selectedDirector) {
      const director = DIRECTORS.find(d => d.name === selectedDirector);
      if (director) {
        finalPrompt = `Directed by ${director.name}. ${director.style} ` + finalPrompt;
      }
    }
    if (selectedStyle) {
      finalPrompt = `In the exact visual style of ${selectedStyle}. ` + finalPrompt;
    }

    navigator.clipboard.writeText(finalPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="group flex flex-col h-full bg-zinc-900/50 border border-zinc-800 rounded-2xl overflow-hidden hover:border-zinc-700 transition-colors">
      <div className="relative aspect-[16/9] overflow-hidden bg-zinc-800">
        <img 
          src={prompt.imageUrl} 
          alt={prompt.title}
          referrerPolicy="no-referrer"
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4">
          <span className="px-3 py-1 bg-zinc-950/80 backdrop-blur-md text-xs font-medium rounded-full border border-zinc-800 text-white">
            {prompt.genre}
          </span>
        </div>
      </div>
      
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-semibold leading-tight text-white mb-2">
          {prompt.title}{showGenreInTitle && prompt.genre && prompt.genre !== 'General' ? ` - ${prompt.genre}` : ''}
        </h3>
        
        <p className="text-zinc-400 text-sm mb-4">
          {prompt.description}
        </p>

        {!prompt.isPremium && prompt.category !== 'Styles' && prompt.category !== 'Directors' && (
          <div className="flex flex-wrap gap-2 mb-4">
            <div className="relative flex-1 min-w-[120px]">
              <select
                value={selectedDirector}
                onChange={(e) => setSelectedDirector(e.target.value)}
                className="w-full appearance-none bg-zinc-950 border border-zinc-800 text-zinc-300 text-xs rounded-lg px-3 py-2 pr-8 focus:outline-none focus:border-emerald-500 transition-colors cursor-pointer"
              >
                <option value="">Realistic (Director)</option>
                {DIRECTORS.map(d => (
                  <option key={d.name} value={d.name}>{d.name}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500 pointer-events-none" />
            </div>
            
            <div className="relative flex-1 min-w-[120px]">
              <select
                value={selectedStyle}
                onChange={(e) => setSelectedStyle(e.target.value)}
                className="w-full appearance-none bg-zinc-950 border border-zinc-800 text-zinc-300 text-xs rounded-lg px-3 py-2 pr-8 focus:outline-none focus:border-emerald-500 transition-colors cursor-pointer"
              >
                <option value="">Add Style</option>
                {STYLES.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500 pointer-events-none" />
            </div>
          </div>
        )}

        <div className="mt-auto bg-zinc-950 rounded-xl p-4 border border-zinc-800/50 relative group/prompt overflow-hidden">
          <p className={`text-zinc-300 text-sm font-mono leading-relaxed line-clamp-3 group-hover/prompt:line-clamp-none transition-all ${prompt.isPremium ? 'blur-[4px] select-none opacity-50' : ''}`}>
            {selectedDirector && !prompt.isPremium && <span className="text-emerald-400">Directed by {selectedDirector}. </span>}
            {selectedStyle && !prompt.isPremium && <span className="text-emerald-400">In the exact visual style of {selectedStyle}. </span>}
            {prompt.promptText}
          </p>
          
          {prompt.isPremium && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-950/40 backdrop-blur-[2px] z-10">
              <div className="bg-zinc-900 border border-zinc-800 px-4 py-2 rounded-full flex items-center gap-2 shadow-xl">
                <Lock className="w-4 h-4 text-emerald-500" />
                <span className="text-sm font-medium text-zinc-200">Pro Creators Only</span>
              </div>
            </div>
          )}
          
          <button 
            onClick={handleCopy}
            disabled={prompt.isPremium}
            className={`absolute top-2 right-2 p-2 rounded-lg transition-colors z-20 ${
              prompt.isPremium 
                ? 'bg-zinc-800/50 text-zinc-500 cursor-not-allowed opacity-100' 
                : 'bg-zinc-800 text-zinc-300 hover:bg-emerald-500 hover:text-white cursor-pointer opacity-0 group-hover/prompt:opacity-100 focus:opacity-100'
            }`}
            title={prompt.isPremium ? "Unlock to Copy" : "Copy Prompt"}
          >
            {copied ? <Check className="w-4 h-4" /> : prompt.isPremium ? <Lock className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
}
