import React from 'react';
import { Upload, Heart, MessageCircle } from 'lucide-react';

const COMMUNITY_POSTS = Array.from({ length: 12 }).map((_, i) => ({
  id: i,
  user: `Creator_${i + 1}`,
  likes: Math.floor(Math.random() * 500) + 10,
  comments: Math.floor(Math.random() * 50) + 1,
  imageUrl: `https://picsum.photos/seed/comm_${i}/600/600`,
  promptUsed: 'Cyberpunk Style - Action'
}));

export function Community() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row items-center justify-between mb-12 gap-6">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Community Showcase</h2>
          <p className="text-zinc-400">See what others are creating with Alpha-Mania prompts.</p>
        </div>
        <button className="px-6 py-3 bg-emerald-500 text-zinc-950 rounded-xl font-semibold flex items-center gap-2 hover:bg-emerald-400 transition-colors cursor-pointer">
          <Upload className="w-5 h-5" />
          Submit Your Art
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {COMMUNITY_POSTS.map(post => (
          <div key={post.id} className="group relative aspect-square rounded-2xl overflow-hidden bg-zinc-900">
            <img 
              src={post.imageUrl} 
              alt={`Art by ${post.user}`} 
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
              <p className="text-white font-medium mb-1">@{post.user}</p>
              <p className="text-emerald-400 text-xs mb-3">Used: {post.promptUsed}</p>
              <div className="flex items-center gap-4 text-zinc-300 text-sm">
                <span className="flex items-center gap-1"><Heart className="w-4 h-4" /> {post.likes}</span>
                <span className="flex items-center gap-1"><MessageCircle className="w-4 h-4" /> {post.comments}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
