import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Code, Palette, Film, ArrowRight, BookOpen, Layers, Zap, Globe } from 'lucide-react';

interface HomeProps {
  onExplore: () => void;
}

export function Home({ onExplore }: HomeProps) {
  return (
    <div className="relative min-h-[calc(100vh-4rem)] overflow-hidden bg-zinc-950">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {/* Cinematic Color Blobs */}
        <motion.div 
          className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-emerald-900/20 rounded-full blur-[120px]"
          animate={{ x: [0, 100, 0], y: [0, 50, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-cyan-900/20 rounded-full blur-[120px]"
          animate={{ x: [0, -100, 0], y: [0, -50, 0] }}
          transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
        />
        
        {/* Subtle Matrix/Code Effect */}
        <div className="absolute inset-0 opacity-[0.03] mix-blend-screen">
          {Array.from({ length: 30 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute text-emerald-500 font-mono text-sm whitespace-pre"
              initial={{ y: -1000, x: `${(i / 30) * 100}%` }}
              animate={{ y: '100vh' }}
              transition={{
                duration: Math.random() * 20 + 20,
                repeat: Infinity,
                ease: 'linear',
                delay: Math.random() * -20,
              }}
            >
              {Array.from({ length: 40 }).map((_, j) => (
                <div key={j} className="my-2">{Math.random() > 0.5 ? '0' : '1'}</div>
              ))}
            </motion.div>
          ))}
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        {/* Hero Section */}
        <div className="text-center max-w-4xl mx-auto mb-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-sm font-medium mb-8 border border-emerald-500/20">
              <Sparkles className="w-4 h-4" />
              <span>The Ultimate Resource for AI Creators</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-white mb-8 leading-tight">
              Empowering <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">Digital Creators</span> to Build the Future
            </h1>
            <p className="text-xl text-zinc-400 leading-relaxed mb-10 max-w-2xl mx-auto">
              Alpha-Mania is designed to push the boundaries of digital art. We provide the ultimate tools, prompts, and inspiration to help you create cinematic, breathtaking masterpieces without limits.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button 
                onClick={onExplore}
                className="w-full sm:w-auto px-8 py-4 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 rounded-xl font-bold flex items-center justify-center gap-2 transition-all hover:scale-105"
              >
                Explore Library
                <ArrowRight className="w-5 h-5" />
              </button>
              <button 
                className="w-full sm:w-auto px-8 py-4 bg-zinc-900 hover:bg-zinc-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all border border-zinc-800"
              >
                Join Community
              </button>
            </div>
          </motion.div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-32">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-zinc-900/50 border border-zinc-800 p-8 rounded-3xl hover:bg-zinc-900 transition-colors"
          >
            <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center mb-6">
              <Layers className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Curated Prompts</h3>
            <p className="text-zinc-400 leading-relaxed">
              Access thousands of highly optimized prompts for Midjourney, Stable Diffusion, and more. Categorized for easy discovery.
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="bg-zinc-900/50 border border-zinc-800 p-8 rounded-3xl hover:bg-zinc-900 transition-colors"
          >
            <div className="w-12 h-12 bg-cyan-500/10 rounded-2xl flex items-center justify-center mb-6">
              <Zap className="w-6 h-6 text-cyan-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Instant Inspiration</h3>
            <p className="text-zinc-400 leading-relaxed">
              Never face creative block again. Browse through cinematic styles, legendary directors, and stunning storyboards.
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="bg-zinc-900/50 border border-zinc-800 p-8 rounded-3xl hover:bg-zinc-900 transition-colors"
          >
            <div className="w-12 h-12 bg-purple-500/10 rounded-2xl flex items-center justify-center mb-6">
              <Globe className="w-6 h-6 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Global Community</h3>
            <p className="text-zinc-400 leading-relaxed">
              Join thousands of other creators. Share your work, get feedback, and collaborate on groundbreaking digital projects.
            </p>
          </motion.div>
        </div>

        {/* About the Creator */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative rounded-3xl overflow-hidden bg-zinc-900/50 border border-zinc-800 p-8 md:p-12"
        >
          <div className="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl" />
          
          <div className="relative z-10 max-w-4xl mx-auto text-center">
            <div className="flex flex-col items-center">
              <h2 className="text-3xl font-bold text-white mb-2">Meet the Creator</h2>
              <h3 className="text-2xl text-emerald-400 font-medium mb-6">Omar Duhaim</h3>
              
              <div className="flex flex-wrap justify-center gap-3 mb-8">
                <span className="px-3 py-1 bg-zinc-800 rounded-full text-sm text-zinc-300 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-400" /> Doctor
                </span>
                <span className="px-3 py-1 bg-zinc-800 rounded-full text-sm text-zinc-300 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-emerald-400" /> Writer
                </span>
                <span className="px-3 py-1 bg-zinc-800 rounded-full text-sm text-zinc-300 flex items-center gap-2">
                  <Code className="w-4 h-4 text-emerald-400" /> Web Designer
                </span>
                <span className="px-3 py-1 bg-zinc-800 rounded-full text-sm text-zinc-300 flex items-center gap-2">
                  <Palette className="w-4 h-4 text-emerald-400" /> Digital Creator
                </span>
                <span className="px-3 py-1 bg-zinc-800 rounded-full text-sm text-zinc-300 flex items-center gap-2">
                  <Film className="w-4 h-4 text-emerald-400" /> Actor
                </span>
              </div>

              <p className="text-zinc-400 leading-relaxed mb-6">
                Currently studying medicine, Omar combines his analytical background with a profound passion for digital art. Following the success of his first major project, <strong className="text-zinc-200">"Alpha-Verse"</strong>, he founded Alpha-Mania to share his extensive knowledge.
              </p>
              <p className="text-zinc-400 leading-relaxed">
                His mission is simple: to provide fellow digital creators with the exact tools, insights, and premium prompts they need to elevate their craft and bring their wildest imaginations to life.
              </p>
              
              <div className="mt-8 p-6 bg-zinc-950/50 rounded-2xl border border-zinc-800/50 inline-block">
                <p className="text-sm font-mono text-emerald-400 mb-2">VISIONARY</p>
                <p className="text-white font-medium">Bridging the gap between medicine, art, and technology.</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
