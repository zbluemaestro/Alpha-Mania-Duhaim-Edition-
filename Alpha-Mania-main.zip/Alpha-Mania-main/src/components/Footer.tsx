import React from 'react';
import { Aperture, Twitter, Github, Linkedin, Mail, Heart } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-zinc-950 border-t border-zinc-900 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center text-zinc-950">
                <Aperture className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-white">Alpha-Mania</span>
            </div>
            <p className="text-zinc-400 text-sm leading-relaxed mb-6">
              Empowering digital creators with premium prompts, styles, and tools to bring their wildest imaginations to life.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="text-zinc-500 hover:text-emerald-400 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-zinc-500 hover:text-emerald-400 transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="text-zinc-500 hover:text-emerald-400 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Explore</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Styles Library</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Directors Cut</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Storyboards</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Freebies</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Resources</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Community</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Pricing</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Tutorials</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Blog</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Legal</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Terms of Service</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Cookie Policy</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-emerald-400 text-sm transition-colors">Contact Us</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-zinc-900 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-zinc-500 text-sm">
            © {new Date().getFullYear()} Alpha-Mania. All rights reserved.
          </p>
          <p className="text-zinc-500 text-sm flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-red-500" /> by Omar Duhaim
          </p>
        </div>
      </div>
    </footer>
  );
}
