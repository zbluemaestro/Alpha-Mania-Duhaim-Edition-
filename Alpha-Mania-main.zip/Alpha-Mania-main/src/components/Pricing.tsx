import React from 'react';
import { Check, Star } from 'lucide-react';

export function Pricing() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Unlock the Full Library</h2>
        <p className="text-xl text-zinc-400 max-w-2xl mx-auto">Choose a plan that fits your creative workflow. Cancel anytime.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        {/* Free Plan */}
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-3xl p-8 flex flex-col">
          <h3 className="text-2xl font-semibold text-white mb-2">Starter</h3>
          <p className="text-zinc-400 mb-6">Perfect for trying out our prompts.</p>
          <div className="mb-8">
            <span className="text-4xl font-bold text-white">$0</span>
            <span className="text-zinc-500">/forever</span>
          </div>
          <ul className="space-y-4 mb-8 flex-grow">
            <li className="flex items-center gap-3 text-zinc-300"><Check className="w-5 h-5 text-emerald-500" /> Access to Freebies tab</li>
            <li className="flex items-center gap-3 text-zinc-300"><Check className="w-5 h-5 text-emerald-500" /> 5 prompt copies per day</li>
            <li className="flex items-center gap-3 text-zinc-300"><Check className="w-5 h-5 text-emerald-500" /> Standard resolution examples</li>
          </ul>
          <button className="w-full py-3 rounded-xl font-semibold bg-zinc-800 text-white hover:bg-zinc-700 transition-colors cursor-pointer">Current Plan</button>
        </div>

        {/* Pro Plan */}
        <div className="bg-emerald-900/20 border border-emerald-500/50 rounded-3xl p-8 flex flex-col relative transform md:-translate-y-4">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-emerald-500 text-zinc-950 px-4 py-1 rounded-full text-sm font-bold flex items-center gap-1">
            <Star className="w-4 h-4" /> Most Popular
          </div>
          <h3 className="text-2xl font-semibold text-white mb-2">Pro Creator</h3>
          <p className="text-emerald-200/70 mb-6">Unlimited access to the entire library.</p>
          <div className="mb-8">
            <span className="text-4xl font-bold text-white">$19</span>
            <span className="text-zinc-500">/month</span>
          </div>
          <ul className="space-y-4 mb-8 flex-grow">
            <li className="flex items-center gap-3 text-zinc-300"><Check className="w-5 h-5 text-emerald-500" /> Unlimited prompt copies</li>
            <li className="flex items-center gap-3 text-zinc-300"><Check className="w-5 h-5 text-emerald-500" /> Access to all categories</li>
            <li className="flex items-center gap-3 text-zinc-300"><Check className="w-5 h-5 text-emerald-500" /> Commercial use license</li>
            <li className="flex items-center gap-3 text-zinc-300"><Check className="w-5 h-5 text-emerald-500" /> Early access to new prompts</li>
          </ul>
          <button className="w-full py-3 rounded-xl font-semibold bg-emerald-500 text-zinc-950 hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20 cursor-pointer">Subscribe Now</button>
        </div>

        {/* Credits Plan */}
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-3xl p-8 flex flex-col">
          <h3 className="text-2xl font-semibold text-white mb-2">Credit Packs</h3>
          <p className="text-zinc-400 mb-6">Pay as you go for specific bundles.</p>
          <div className="mb-8">
            <span className="text-4xl font-bold text-white">$5</span>
            <span className="text-zinc-500">/50 credits</span>
          </div>
          <ul className="space-y-4 mb-8 flex-grow">
            <li className="flex items-center gap-3 text-zinc-300"><Check className="w-5 h-5 text-emerald-500" /> Buy specific prompt bundles</li>
            <li className="flex items-center gap-3 text-zinc-300"><Check className="w-5 h-5 text-emerald-500" /> Credits never expire</li>
            <li className="flex items-center gap-3 text-zinc-300"><Check className="w-5 h-5 text-emerald-500" /> Access to premium community</li>
          </ul>
          <button className="w-full py-3 rounded-xl font-semibold bg-zinc-800 text-white hover:bg-zinc-700 transition-colors cursor-pointer">Buy Credits</button>
        </div>
      </div>
    </section>
  );
}
