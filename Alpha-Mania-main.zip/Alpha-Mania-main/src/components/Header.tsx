import React, { useState } from 'react';
import { Category, ViewMode } from '../types';
import { Film, Image as ImageIcon, Video, Music, LayoutTemplate, Menu, X, Users, Aperture, BookOpen, Gift, CreditCard, Globe, Home } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  activeCategory: Category;
  onSelectCategory: (category: Category) => void;
  currentView: ViewMode;
  onSelectView: (view: ViewMode) => void;
}

const NAV_ITEMS: { label: Category; icon: React.ElementType }[] = [
  { label: 'Styles', icon: ImageIcon },
  { label: 'Directors', icon: Film },
  { label: 'Storyboards', icon: BookOpen },
  { label: 'Video', icon: Video },
  { label: 'Music', icon: Music },
  { label: 'Posters', icon: LayoutTemplate },
  { label: 'Characters', icon: Users },
  { label: 'Freebies', icon: Gift },
];

export function Header({ activeCategory, onSelectCategory, currentView, onSelectView }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-zinc-950/80 border-b border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onSelectView('Home')}>
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center text-zinc-950">
            <Aperture className="w-5 h-5" />
          </div>
          <span className="text-xl font-bold tracking-tight text-white hidden sm:block">Alpha-Mania</span>
        </div>
        
        {/* Desktop Nav - Grouped on the right */}
        <div className="hidden md:flex items-center gap-2">
          {/* Main Views (Left side of nav) */}
          <div className="flex items-center gap-1 border-r border-zinc-800 pr-2 mr-1">
            <button
              onClick={() => onSelectView('Home')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                currentView === 'Home'
                  ? 'text-emerald-400 bg-emerald-500/10'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
              }`}
            >
              <Home className="w-4 h-4" />
              Home
            </button>
          </div>

          {/* Categories */}
          <nav className="flex items-center gap-0.5">
            {NAV_ITEMS.map(({ label, icon: Icon }) => (
              <button
                key={label}
                onClick={() => {
                  onSelectCategory(label);
                  onSelectView('Library');
                }}
                className={`px-2 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                  activeCategory === label && currentView === 'Library'
                    ? 'bg-zinc-800 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {label}
              </button>
            ))}
          </nav>

          {/* Other Views (Right side of nav) */}
          <div className="flex items-center gap-1 border-l border-zinc-800 pl-2 ml-1">
            <button
              onClick={() => onSelectView('Community')}
              className={`px-2 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                currentView === 'Community'
                  ? 'text-emerald-400 bg-emerald-500/10'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              Community
            </button>
            <button
              onClick={() => onSelectView('Pricing')}
              className={`px-2 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                currentView === 'Pricing'
                  ? 'text-emerald-400 bg-emerald-500/10'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              Pricing
            </button>
          </div>
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden p-2 text-zinc-400 hover:text-white cursor-pointer"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.nav
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden border-t border-zinc-800 bg-zinc-950 overflow-hidden max-h-[calc(100vh-4rem)] overflow-y-auto"
          >
            <div className="px-4 py-4 space-y-4">
              <div className="space-y-1">
                <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2 px-4">Main</p>
                <button
                  onClick={() => {
                    onSelectView('Home');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full px-4 py-3 rounded-lg text-left text-sm font-medium flex items-center gap-3 transition-colors cursor-pointer ${
                    currentView === 'Home'
                      ? 'bg-emerald-500/10 text-emerald-400'
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                  }`}
                >
                  <Home className="w-5 h-5" />
                  Home
                </button>
              </div>

              <div className="border-t border-zinc-800 pt-4 space-y-1">
                <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2 px-4">Library</p>
                {NAV_ITEMS.map(({ label, icon: Icon }) => (
                  <button
                    key={label}
                    onClick={() => {
                      onSelectCategory(label);
                      onSelectView('Library');
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full px-4 py-3 rounded-lg text-left text-sm font-medium flex items-center gap-3 transition-colors cursor-pointer ${
                      activeCategory === label && currentView === 'Library'
                        ? 'bg-zinc-800 text-white'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {label}
                  </button>
                ))}
              </div>
              
              <div className="border-t border-zinc-800 pt-4 space-y-1">
                <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2 px-4">Explore</p>
                <button
                  onClick={() => {
                    onSelectView('Community');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full px-4 py-3 rounded-lg text-left text-sm font-medium flex items-center gap-3 transition-colors cursor-pointer ${
                    currentView === 'Community'
                      ? 'bg-emerald-500/10 text-emerald-400'
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                  }`}
                >
                  <Globe className="w-5 h-5" />
                  Community
                </button>
                <button
                  onClick={() => {
                    onSelectView('Pricing');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full px-4 py-3 rounded-lg text-left text-sm font-medium flex items-center gap-3 transition-colors cursor-pointer ${
                    currentView === 'Pricing'
                      ? 'bg-emerald-500/10 text-emerald-400'
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                  }`}
                >
                  <CreditCard className="w-5 h-5" />
                  Pricing
                </button>
              </div>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
