import React, { useState } from 'react';
import { prompts, GENRES } from '../data/database';
import { PromptCard } from './PromptCard';
import { Category } from '../types';
import { motion } from 'motion/react';

interface CategoryViewProps {
  category: Category;
}

export function CategoryView({ category }: CategoryViewProps) {
  const [activeGenre, setActiveGenre] = useState<string>('General');

  const categoryPrompts = prompts.filter(p => p.category === category);
  
  let filteredPrompts = [];
  if (activeGenre === 'General') {
    const seen = new Set();
    filteredPrompts = categoryPrompts.filter(p => {
      if (seen.has(p.title)) return false;
      seen.add(p.title);
      return true;
    });
  } else {
    filteredPrompts = categoryPrompts.filter(p => p.genre === activeGenre);
  }

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12" id="prompts">
      <div className="flex flex-col md:flex-row md:items-start justify-between mb-12 gap-6">
        <h2 className="text-3xl font-bold tracking-tight text-white shrink-0">{category} Library</h2>
        
        <div className="flex flex-wrap gap-2 justify-end">
          <button
            onClick={() => setActiveGenre('General')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors cursor-pointer ${
              activeGenre === 'General' 
                ? 'bg-emerald-500 text-white' 
                : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800'
            }`}
          >
            General
          </button>
          {GENRES.map(genre => (
            <button
              key={genre}
              onClick={() => setActiveGenre(genre)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors cursor-pointer ${
                activeGenre === genre 
                  ? 'bg-emerald-500 text-white' 
                  : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800'
              }`}
            >
              {genre}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredPrompts.map((prompt, index) => (
          <motion.div
            key={prompt.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: (index % 10) * 0.1 }}
          >
            <PromptCard prompt={prompt} showGenreInTitle={activeGenre !== 'General'} />
          </motion.div>
        ))}
      </div>
      
      {filteredPrompts.length === 0 && (
        <div className="text-center py-24 text-zinc-500">
          <p className="text-lg">No prompts found in this category for the selected genre.</p>
        </div>
      )}
    </section>
  );
}
